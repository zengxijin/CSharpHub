﻿
using Service.ServiceReference1;
using Service.ServiceReference2;
using Service.XHE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Util
{
    public class ServiceInvoke
    {
        //旧的生产接口地址：http://10.85.32.253:7001/sjpt_his_village/Data_Update_M.ws
        private static Data_Update_IPortTypeClient clientPrd = null;
        private static Data_Update_MSoapClient clientTest = null;
        private static object lockObj = new object();

        //新的接口地址：http://10.192.200.30:7001/cxjmsi/InterFace.ws
        private static InterFace_IPortTypeClient clientPrdV2 = null;

        public static string Update_Data_String(string procName,string parames,string split) 
        {
            if (ConfigUtil.isEnvPrd() == true) 
            {
                //生产环境接口
                //return getXnhClient().Update_Data_String(procName, parames, split);

                //2018-01-05 转为使用新的接口地址
                return getXnhClientV2().Update_Data_String(procName, parames, split);
            }
            else 
            {
                //模拟环境接口
                return getWebSoapClient().Update_Data_String(procName, parames, split);
            }
        }

        public static string Execute_Sql(string sqlStr,string parames,string split)
        {
            if (ConfigUtil.isEnvPrd() == true)
            {
                //生产环境接口
                //return getXnhClient().Execute_Sql(sqlStr, parames, split);

                //2018-01-05 转为使用新的接口地址
                return getXnhClientV2().Execute_Sql(sqlStr, parames, split);
            }
            else
            {
                //模拟环境接口
                return getWebSoapClient().Execute_Sql(sqlStr, parames, split);
            }
        }

        private static Data_Update_MSoapClient getWebSoapClient()
        {
            if (clientTest == null)
            {
                lock (lockObj)
                {
                    if (clientTest == null)
                    {
                        clientTest = new Data_Update_MSoapClient();
                    }
                }
            }
            return clientTest;
        }

        private static Data_Update_IPortTypeClient getXnhClient()
        {
            if (clientPrd == null)
            {
                lock (lockObj)
                {
                    if (clientPrd == null)
                    {
                        clientPrd = new Data_Update_IPortTypeClient();
                    }
                }
            }
            return clientPrd;
        }

        private static InterFace_IPortTypeClient getXnhClientV2()
        {
            if (clientPrdV2 == null)
            {
                lock (lockObj)
                {
                    if (clientPrdV2 == null)
                    {
                        clientPrdV2 = new InterFace_IPortTypeClient();
                    }
                }
            }

            return clientPrdV2;
        }
    }
}
